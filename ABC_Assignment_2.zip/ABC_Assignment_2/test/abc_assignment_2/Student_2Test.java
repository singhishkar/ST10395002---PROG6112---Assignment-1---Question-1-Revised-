/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package abc_assignment_2;

import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ishka
 */
public class Student_2Test {
    
    public Student_2Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Start");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("End");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of SaveStudent method, of class Student_2.
     */
    @Test
    public void testSaveStudent() {
        int testId = 123;
        String testName = "John Doe";
        int testAge = 18;
        String testEmail = "johndoe@example.com";
        String testCourse = "Computer Science";

       // Student.kb = new Scanner("123\nJohn Doe\n18\njohndoe@example.com\nComputer Science\n");
       
       Student_2 mo = new Student_2();
       Student_2.ID.add(123);
       Student_2.age.add(18);
       Student_2.course.add("Computer Science");
       Student_2.email.add("johndoe@example.com");
       Student_2.name.add( "John Doe");
        //Check if the student details are saved correctly
      assertEquals(1, Student_2.ID.size());


        assertEquals(testName, Student_2.name.get(0));
        assertEquals(testEmail, Student_2.email.get(0));
        assertEquals(testCourse, Student_2.course.get(0));
    }

    /**
     * Test of SearchStudent method, of class Student_2.
     */
    @Test
    public void testSearchStudentFound() {
      Student_2 stu = new Student_2();
 stu.ID.add(321);
stu.name.add("Reginal");
stu.age.add(16);
stu.email.add("reginal@gmail.com");
stu.course.add("BCAD");

Scanner scanner = new Scanner ("321\n\n");

String found= stu. SearchStudent(321,scanner);
String res="found";
assertEquals(found,res);
    }
       @Test
    public void testSearchStudentNotFound() {
      Student_2 stu = new Student_2();
      stu.ID.add(321);
stu.name.add("Reginal");
stu.age.add(16);
stu.email.add("reginal@gmail.com");
stu.course.add("BCAD");

Scanner scanner = new Scanner ("123\n\n");

String found= stu. SearchStudent(123,scanner);
String res="found";
//assertNotEquals(found,res);
assertNotNull(found);
    }

    /**
     * Test of DeleteStudent method, of class Student_2.
     */
    @Test
    public void testDeleteStudent() {
     //Add a student to the database
        Student_2.ID.add(123); 
        Student_2.name.add("Caleb"); 
        Student_2.age.add(20);
        Student_2.email.add("Caleb@gmail.com"); 
        Student_2.course.add("Math");
Student_2 mo = new Student_2();
        // Call the DeleteStudent method with the student's ID
        Scanner scanner = new Scanner("123\n\ny\n\n");
       int res= mo.DeleteStudent(scanner);
int exp=1;
        // Assert that the student has been successfully deleted
        assertEquals(exp,res);
    }
    @Test
    public void testDeleteStudentNotFound() {
     //Add a student to the database
        Student_2.ID.add(123); 
        Student_2.name.add("Reginal"); 
        Student_2.age.add(20);
        Student_2.email.add("reginal@gmail.com"); 
        Student_2.course.add("Math");
Student_2 mo = new Student_2();
        // Call the DeleteStudent method with the student's ID
        Scanner scanner = new Scanner("321\n\ny\n\n");
       int res= mo.DeleteStudent(scanner);
int exp=1;
        // Assert that the student has been successfully deleted
        assertNotEquals(exp,res);
    }

@Test 
public void testAgeValid(){
   Scanner scan = new Scanner("17");
   
Student_2 mo = new Student_2();
   int valid= mo.AgeValidityCheck(scan);
   int exp= 1;
   assertEquals(exp,valid);
   
    
}
@Test 
public void testAgeInValid(){
   Scanner scan = new Scanner("12\n17");
Student_2 mo = new Student_2();
   int valid= mo.AgeValidityCheck(scan);
   int exp= 0;
   assertNotEquals(exp,valid);
   
    
}
@Test 
public void testAgeInValidCharacter(){
   Scanner scan = new Scanner("a\n17");
Student_2 mo = new Student_2();
   int valid= mo.AgeValidityCheck(scan);
   int exp= 0;
   assertNotEquals(exp,valid);
   
    
}
    
}
