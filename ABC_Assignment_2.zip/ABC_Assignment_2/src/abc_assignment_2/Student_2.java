/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_assignment_2;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class Student_2 {
    
 public final static Scanner kb = new Scanner(System.in);
    
    //Instantiate the ABC_College class to access its menuLaunch method
  public static ABC_Assignment_2 college = new ABC_Assignment_2();
    
    public static ArrayList<Integer> ID = new ArrayList<>();
    public static ArrayList<String> name = new ArrayList<>();
    public static ArrayList<Integer> age = new ArrayList<>();
    public static ArrayList<String> email = new ArrayList<>();
    public static ArrayList<String> course = new ArrayList<>();
    
    public void SaveStudent() { 
        //Captures and saves a new student's information.
        System.out.println("CAPTURE A NEW STUDENT\n"
            + "****************************************");
     
        System.out.print("Enter the student ID: ");
        int identification = kb.nextInt();
        ID.add(identification);
        
        kb.nextLine(); // Consume the newline character left by previous nextInt()
        
        System.out.print("Enter the student name: ");
        String studentName = kb.nextLine();
        name.add(studentName);
        
        int ageRestriction = 16;
        int studentAge;
        
        do {
            try {
                System.out.print("Enter the student age: ");
                studentAge = kb.nextInt();

                if (studentAge < ageRestriction) {
                    System.out.println("You have entered an incorrect age!!!\n"
                            + "Age should be greater than or equal to " + ageRestriction + "\n"
                            + "Please re-enter the student age >>");
                } else {
                    age.add(studentAge); // Add age to ArrayList after validation
                }
            } catch (InputMismatchException e) {
                System.out.println("You have entered an incorrect age!!!\n"
                        + "Age should be greater than or equal to " + ageRestriction + "\n"
                        + "Please re-enter the student age >>");
                kb.nextLine(); // Clear the input buffer
                studentAge = -1; // Set a value that triggers reprompt
            }
        } while (studentAge < ageRestriction);

        kb.nextLine(); // Consume the newline character left by previous nextInt()
        
        String studentEmail;
        do {
            System.out.print("Enter the student email: ");
            studentEmail = kb.nextLine();

            if (!studentEmail.contains("@")) {
                System.out.println("Email must contain '@' symbol.");
            } else {
                email.add(studentEmail); // Add email to ArrayList after validation
            }
        } while (!studentEmail.contains("@"));
        
        System.out.print("Enter the student course: ");
        String studentCourse = kb.nextLine();
        course.add(studentCourse);
        
        System.out.println("The student details have been successfully saved.");
        //System.out.println("");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        college.menuLaunch(kb);
    }
    
    //Searches for a student by their ID and displays their information
    public static String SearchStudent(int studentId,Scanner kb) {
        String val=null;
        
        if (ID.isEmpty()) {
            System.out.println("Student database empty.");
            System.out.println("----------------------------------------");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            college.menuLaunch(kb);
            val=null; // Exit the method if the database is empty
        }

        System.out.print("Enter the student ID to search: ");
        studentId = kb.nextInt();
        System.out.println("----------------------------------------");
        
        boolean found = false; // Flag to track if the ID was found

        for (int i = 0; i < ID.size(); i++) {
            if (ID.get(i) == studentId) {
                System.out.println("STUDENT ID: " + ID.get(i) + "\n"
                        + "STUDENT NAME: " + name.get(i) + "\n"
                        + "STUDENT AGE: " + age.get(i) + "\n"
                        + "STUDENT EMAIL: " + email.get(i) + "\n"
                        + "STUDENT COURSE: " + course.get(i));
                found = true; // Set the flag to true
                val="found";
                break; // Once found and deleted, no need to continue the loop
            }
            val=null;
        }

        if (!found) {
            System.out.print("Student with student ID: " + studentId + " was not found!" + "\n");
            val=null;
        }

        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        college.menuLaunch(kb);
        
        return val;
    }

    //Deletes a student's information by their ID
    public int DeleteStudent(Scanner kb) {
        int ret=0;
        if (ID.isEmpty()) {
        System.out.println("Student database empty.");
        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        college.menuLaunch(kb);
        ret=0;
        }
        
        System.out.print("Enter the ID to delete: ");
        int IDremove = kb.nextInt();
        System.out.println("----------------------------------------");

        boolean found = false; // Flag to track if the ID was found
        boolean cancel = false;
        boolean correctOption = false;
        
        for (int i = 0; i < ID.size(); i++) {
            if (ID.get(i) == IDremove) {
                while(!correctOption) {
                System.out.println("Are you sure you want to delete " + ID.get(i) + " from the system? Yes (y) to delete or No (n) to cancel.");
                String deleteConfirmation = kb.next();
                
                switch (deleteConfirmation.toLowerCase()) {
                    case "y" ->
                    {
                        ID.remove(i);
                        name.remove(i);
                        age.remove(i);
                        email.remove(i);
                        course.remove(i);
                        found = true; // Set the flag to true
                        correctOption = true;
                        ret=1;
                        break;
                    }
                    case "n" ->
                    {
                        System.out.println("----------------------------------------");
                        cancel = true;
                        correctOption = true;
                        break;
                    
                    }
                    default -> System.out.println("Please enter only one of the following options: \"y\" or \"n\": ");
                }
             }
           }
            ret=0;
        }
        
        //kb.close();

        if (found) {
            System.out.println("The student details have been deleted successfully.");
            ret=1;
        } else if (cancel) {
            System.out.println("Deletion aborted...");
        }
        else {
            System.out.println("Student with ID " + IDremove + " not found.");
        }

        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        college.menuLaunch(kb);
        
        return ret;
    }
    
    //Displays a report of all students in the database
    public void StudentReport(Scanner kb) {  
        if (ID.isEmpty()) {
            System.out.println("Student database empty.");
            System.out.println("----------------------------------------");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            college.menuLaunch(kb);
        }
        
        for (int i = 0; i < ID.size(); i++)
        {
            System.out.println("\nSTUDENT " + (i+1) + "\n"
                    + "----------------------------------------\n"
                    + "STUDENT ID: " + ID.get(i) + "\n"
                    + "STUDENT NAME: " + name.get(i) + "\n" 
                    + "STUDENT AGE: " + age.get(i) + "\n"
                    + "STUDENT EMAIL: " + email.get(i) + "\n"
                    + "STUDENT COURSE: " + course.get(i));
        }
        
        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        college.menuLaunch(kb);
    }
    
    //Exits the student application
    public void ExitStudentApplication(Scanner kb) {
        System.out.println("Thank you for using the Student Management Application!");
        System.out.println("Exiting program...");

    }
     public int AgeValidityCheck(Scanner kb){
       
        int ret=0;

        
        int ageRestriction = 16;
        int studentAge;
        
        do {
            try {
                System.out.print("Enter the student age: ");
                studentAge = kb.nextInt();

                if (studentAge < ageRestriction) {
                    System.out.println("You have entered an incorrect age!!!\n"
                            + "Age should be greater than or equal to " + ageRestriction + "\n"
                            + "Please re-enter the student age >>");
                    ret=0;
                } else {
                    age.add(studentAge); // Add age to ArrayList after validation
                    ret=1;
                }
            } catch (InputMismatchException e) {
                System.out.println("You have entered an incorrect age!!!\n"
                        + "Age should be greater than or equal to " + ageRestriction + "\n"
                        + "Please re-enter the student age >>");
                kb.nextLine(); // Clear the input buffer
                studentAge = -1; // Set a value that triggers reprompt
            }
        } while (studentAge < ageRestriction);

        return ret;
    }
}
